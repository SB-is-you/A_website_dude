# Polygon-drawer Info
A polygon generator coded by python.

# How to use it?

First,type a number into the box,minimum is 3,max is 360.

Next,waiting for the drawing

Boom!you have perfect polygon!

Enter [y] to draw again.

Thank you!
